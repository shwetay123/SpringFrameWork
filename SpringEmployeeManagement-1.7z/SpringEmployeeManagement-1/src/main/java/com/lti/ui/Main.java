package com.lti.ui;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.model.Employee;
import com.lti.service.EmployeeService;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		Employee employee = context.getBean("employee", Employee.class);
		
		EmployeeService services =  context.getBean("service", EmployeeService.class);
		boolean result = services.addEmployee(employee);
		System.out.println(employee);
		/*if(result){
			System.out.println("Employee added successfully..." + employee);
		}else{
			System.out.println("Failed to add..");
		}
		List<Employee> list = services.findAllEmployyees();
		System.out.println(list);*/
	}

}
