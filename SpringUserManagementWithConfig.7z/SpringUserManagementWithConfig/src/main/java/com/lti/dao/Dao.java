package com.lti.dao;

import java.util.List;

import com.lti.model.Users;

public interface Dao {
	int readLogin(String username, String password);
	public int updateUser(Users user);
	public List<Users> readAllUsers();
	public int deleteUser(String username);
	public int createUser(Users user);
	public List<Users> findUser(String username);
	

}
