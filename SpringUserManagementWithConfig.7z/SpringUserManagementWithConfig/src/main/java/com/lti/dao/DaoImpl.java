package com.lti.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.lti.model.Users;


@Service("service")
public class DaoImpl implements Dao {
	
	
	private JdbcTemplate template;

	public DaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}

	private static final String INSERT_EMP_RECORD = "Insert into users(username, FIRSTNAME, LASTNAME, MOBILENUMBER, PASSWORD) values (?, ?, ?, ?, ?)";
	private static final String DELETE_EMP_RECORD = "Delete from users where username=?";
	private static final String UPDATE_EMP_RECORD = "Update users set MOBILENUMBER=? where username=?";
	private static final String SELECT_EMP_RECORD = "select * from users";
	private static final String CHECK_LOGIN = " select * from users where USERNAME=? and PASSWORD=? ";
	private static final String Find_User = "select * from users where username=?";

	public DaoImpl() {

	}

	public int readLogin(String username, String password) {
		List<Users> list = template.query(CHECK_LOGIN, new Object[] { username, password }, new UsersRowMapper());
		return list != null ? list.size() : 0;
	}

	public int updateUser(Users user) {
		int result = template.update(UPDATE_EMP_RECORD, user.getMobilenumber(), user.getUsername());
		return result;
	}

	public List<Users> readAllUsers() {
		List<Users> list = template.query(SELECT_EMP_RECORD, new UsersRowMapper());
		return list;

	}

	public int deleteUser(String username) {
		int result = template.update(DELETE_EMP_RECORD, username);
		return result;
	}

	public int createUser(Users user) {
		int result = template.update(INSERT_EMP_RECORD, user.getUsername(), user.getFirstname(), user.getFirstname(),
				user.getMobilenumber(), user.getPassword());
		return result;
	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public List<Users> findUser(String username) {
		List<Users> user = template.query(Find_User, new Object[] { username }, new UsersRowMapper());
		return user;
	}

}
