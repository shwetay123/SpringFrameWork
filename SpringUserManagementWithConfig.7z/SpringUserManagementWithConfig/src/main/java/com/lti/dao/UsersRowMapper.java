package com.lti.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.lti.model.Users;

public class UsersRowMapper implements RowMapper<Users> {

	public Users mapRow(ResultSet rs, int arg1) throws SQLException {
		int cnt=0;
		System.out.println(++cnt);
		Users user = new Users();
		user.setUsername(rs.getString("USERNAME"));
		user.setFirstname(rs.getString("FIRSTNAME"));
		user.setLastname(rs.getString("LASTNAME"));
		user.setMobilenumber(rs.getString("MOBILENUMBER"));
		user.setPassword(rs.getString("PASSWORD"));
		return user;
	}

}
