package com.lti.service;

import java.util.List;

import com.lti.dao.Dao;
import com.lti.model.Users;


@org.springframework.stereotype.Service("service")
public class ServiceImpl implements Service {
	
	
	private Dao dao = null;

	public ServiceImpl(Dao dao) {
		super();
		this.dao = dao;
	}

	public ServiceImpl() {

	}

	public boolean checkLogin(String username, String password) {
		int result = getDao().readLogin(username, password);
		if (result == 1)
			return true;
		else
			return false;
	}

	public List<Users> findAllUsers() {
		return dao.readAllUsers();
	}

	public boolean removeUser(String username) {
		int result = getDao().deleteUser(username);
		if (result == 1)
			return true;
		else
			return false;
	}

	public List<Users> findUserByUsername(String username) {
		List<Users> user = dao.findUser(username);

		if (user != null) {
			return user;
		}
		return null;
	}

	public boolean addUser(Users user) {
		int result = getDao().createUser(user);
		if (result == 1)
			return true;
		else
			return false;
	}

	public boolean updateUser(Users user) {
		int result = dao.updateUser(user);
		if (result == 1)
			return true;
		else
			return false;
	}

	public Dao getDao() {
		return dao;
	}

	public void setDao(Dao dao) {
		this.dao = dao;
	}
}
