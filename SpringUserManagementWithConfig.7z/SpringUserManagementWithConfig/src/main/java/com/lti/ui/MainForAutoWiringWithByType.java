package com.lti.ui;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.model.Users;
import com.lti.service.Service;
import com.lti.service.ServiceImpl;

public class MainForAutoWiringWithByType {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("configForAutowiringWithByType.xml");
		Service service = context.getBean("service1", ServiceImpl.class);
		Users user = context.getBean("users", Users.class);

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Username & password");
		String username = sc.next();
		String password = sc.next();

		boolean result = service.checkLogin(username, password);
		if (result) {
			System.out.println("Welcome " + username);
			int ans = 0;
			do {
				boolean result1;
				int choice = 0;
				System.out.println("1. Insert \n 2. Update \n 3. Delete \n 4. Find");
				choice = sc.nextInt();
				switch (choice) {

				case 1:
					System.out.println("Enter username, password, firstname, lastname, mobilenumber");
					String uname = sc.next();
					String pass = sc.next();
					String fname = sc.next();
					String lname = sc.next();
					String mobno = sc.next();

					user.setUsername(uname);
					user.setPassword(pass);
					user.setFirstname(fname);
					user.setLastname(lname);
					user.setMobilenumber(mobno);

					result1 = service.addUser(user);
					if (result) {
						System.out.println("User is added in database");
					}

					break;

				case 2:
					System.out.println("Enter username ");
					String username1 = sc.next();
					user.setUsername(username1);
					System.out.println("Enter new mobile no:");
					String mobno1 = sc.next();
					user.setMobilenumber(mobno1);
					boolean result11 = service.updateUser(user);

					if (result11)
						System.out.println("User Updated");
					else
						System.out.println("Failed to update");

					break;

				case 3:
					System.out.println("Enter username ");
					String username2 = sc.next();
					List<Users> user1 = service.findUserByUsername(username2);
					if (user1 != null) {
						boolean res = service.removeUser(username2);
						if (res) {
							System.out.println("USer deleted");
						} else {
							System.out.println("Failed to delete");
						}

					} else {
						System.out.println("No user with " + username2);
					}
					break;

				case 4:
					List<Users> list = service.findAllUsers();
					//System.out.println(list);
					if(list != null){
						for(Users s : list) {
							System.out.println(s);
						}
					}else{
						System.out.println("Failed to fetch all data ");
					}
					
					break;

				default:
					System.out.println("Enter valid option");
					break;
				}

				System.out.println("Do you want to continue");
				ans = sc.nextInt();

			} while (ans == 1);

		} else {
			System.out.println("Sorry Invalid credentials ");

		}

		service.findAllUsers();

	}

}
