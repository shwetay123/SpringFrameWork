package com.lti.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.lti.model.Users;

@Configuration
@ComponentScan(basePackages={"com.lti"})
public class AppConfig {
	
	@Bean("user")
	public  Users getUsers(){
		Users user = new Users();
		return user;
	}
	
	@Bean
	public JdbcTemplate getJdbcTemplate(){
		JdbcTemplate template = new JdbcTemplate();
		return template;
		
	}
	
	
}
